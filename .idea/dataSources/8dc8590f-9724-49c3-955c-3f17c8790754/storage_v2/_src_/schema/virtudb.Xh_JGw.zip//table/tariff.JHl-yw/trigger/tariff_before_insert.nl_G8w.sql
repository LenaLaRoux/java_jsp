create definer = root@localhost trigger tariff_BEFORE_INSERT
    before INSERT
    on tariff
    for each row
BEGIN
    INSERT INTO messagelog (message, logtime) 
    values ( NEW.type , now());
END;

